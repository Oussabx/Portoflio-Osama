// Your portfolio content. Edit it with admin.html (or by hand).
window.PORTFOLIO = {
  "site": {
    "name": "Osama",
    "initials": "O",
    "title": "UI/UX Designer & Front-End Developer",
    "hero": {
      "availability": "Available for freelance & full-time roles",
      "showAvailability": true,
      "headline": "I design interfaces people *enjoy* using — and build them, too.",
      "lead": "UI/UX designer & front-end developer turning research and rough ideas into clear, accessible, fast products. From first sketch in Figma to production code.",
      "stats": [
        {
          "value": "5+",
          "label": "Shipped projects"
        },
        {
          "value": "Design → Code",
          "label": "End-to-end ownership"
        },
        {
          "value": "100",
          "label": "Lighthouse accessibility"
        }
      ]
    },
    "about": {
      "heading": "Designer by training, developer by curiosity.",
      "photo": "",
      "paragraphs": [
        "I'm Osama, a UI/UX designer and front-end developer based in Your City. I care about the whole journey: understanding users, mapping flows, crafting pixel-level UI, and shipping it as clean, responsive code.",
        "My process is simple — listen, prototype early, test with real people, and iterate until the interface feels obvious."
      ],
      "skillGroups": [
        {
          "name": "Design",
          "skills": [
            "Figma",
            "User research",
            "Wireframing",
            "Prototyping",
            "Design systems",
            "Usability testing"
          ]
        },
        {
          "name": "Development",
          "skills": [
            "HTML",
            "CSS",
            "JavaScript",
            "React",
            "Responsive design",
            "Accessibility"
          ]
        }
      ]
    },
    "contact": {
      "heading": "Let's build something great together.",
      "text": "Have a project, a role, or just a question? My inbox is always open — I usually reply within a day.",
      "email": "you@example.com",
      "formEndpoint": "",
      "socials": [
        {
          "label": "GitHub",
          "url": "https://github.com/oussabx"
        },
        {
          "label": "LinkedIn",
          "url": "https://www.linkedin.com/"
        },
        {
          "label": "Dribbble",
          "url": "https://dribbble.com/"
        },
        {
          "label": "Behance",
          "url": "https://www.behance.net/"
        }
      ]
    }
  },
  "projects": [
    {
      "title": "Pet Hero — Mobile Grooming",
      "summary": "Multi-page marketing site for a mobile pet grooming van in Beirut: playful illustrated brand, booking via WhatsApp, fully responsive and dependency-free.",
      "role": "UI design · Front-end",
      "categories": [
        "uiux",
        "dev"
      ],
      "tags": [
        "HTML",
        "CSS",
        "JavaScript",
        "SVG illustration"
      ],
      "image": "assets/projects/pet-hero.svg",
      "links": [
        {
          "label": "Source",
          "href": "https://github.com/oussabx/projects"
        }
      ],
      "visible": true
    },
    {
      "title": "Fintech App Onboarding",
      "summary": "Placeholder — redesigned a 7-step sign-up into 3 screens after usability testing, cutting drop-off. Replace with your own case study.",
      "role": "UX research · UI design",
      "categories": [
        "uiux"
      ],
      "tags": [
        "Figma",
        "User testing",
        "Prototyping"
      ],
      "image": "assets/projects/onboarding.svg",
      "links": [],
      "visible": true
    },
    {
      "title": "Design System Starter",
      "summary": "Placeholder — tokens, components and documentation shared between Figma and code so design and dev stay in sync.",
      "role": "Design systems · Front-end",
      "categories": [
        "uiux",
        "dev"
      ],
      "tags": [
        "Figma",
        "CSS variables",
        "Storybook"
      ],
      "image": "assets/projects/design-system.svg",
      "links": [],
      "visible": true
    },
    {
      "title": "Analytics Dashboard",
      "summary": "Placeholder — responsive React dashboard with filters, charts and a dark mode, built from a Figma prototype.",
      "role": "Front-end development",
      "categories": [
        "dev"
      ],
      "tags": [
        "React",
        "Charts",
        "Accessibility"
      ],
      "image": "assets/projects/dashboard.svg",
      "links": [],
      "visible": true
    }
  ]
};
